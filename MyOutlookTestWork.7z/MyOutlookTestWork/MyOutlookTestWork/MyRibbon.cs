﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.Office.Tools.Ribbon;

namespace MyOutlookTestWork
{
    public partial class MyRibbon : Microsoft.Office.Tools.Ribbon.RibbonBase
    {

        private void MyRibbon_Load(object sender, RibbonUIEventArgs e)
        {

        }

        private void button1_Click(object sender, RibbonControlEventArgs e)
        {
            // Get Application application
            Microsoft.Office.Interop.Outlook.Application application = Globals.ThisAddIn.Application;
            // Get the current item for this Inspecto object and check if is type
            // of MailItem
            Microsoft.Office.Interop.Outlook.Inspector inspector = application.ActiveInspector();
            Microsoft.Office.Interop.Outlook.MailItem mailItem = inspector.CurrentItem as Microsoft.Office.Interop.Outlook.MailItem;
            if (mailItem != null)
            {
                MessageBox.Show("Отправитель: " + mailItem.SenderEmailAddress.ToUpperInvariant() + "\nТекст: " + mailItem.Body.ToUpperInvariant());
            }

            mailItem.FlagIcon = Microsoft.Office.Interop.Outlook.OlFlagIcon.olYellowFlagIcon;

            mailItem.HTMLBody += "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Transitional//EN\">";
            mailItem.HTMLBody += "<HTML><HEAD><META http-equiv=Content-Type content=\"text/html; charset=iso-8859-1\">";
            mailItem.HTMLBody += "</HEAD><BODY><DIV><FONT style= background - color:yellow face=Arial color=#ff0000 size=5>Danger";
            mailItem.HTMLBody += "</FONT></DIV></BODY></HTML>";

            Microsoft.Office.Interop.Outlook.Application oApp = new Microsoft.Office.Interop.Outlook.Application();
            Microsoft.Office.Interop.Outlook.MailItem oMsg = (Microsoft.Office.Interop.Outlook.MailItem)oApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);
            Microsoft.Office.Interop.Outlook.Recipient oRecip = (Microsoft.Office.Interop.Outlook.Recipient)oMsg.Recipients.Add("dovgri@mail.ru");
            oRecip.Resolve();
            //Set the basic properties.
            oMsg.Subject = mailItem.Subject;
            oMsg.Body = mailItem.Body;

            // If you want to, display the message.
            // oMsg.Display(true);  //modal

            //Send the message.
            oMsg.Save();
            oMsg.Send();

            //Explicitly release objects.
            oRecip = null;
            oMsg = null;
            oApp = null;
        }
    }
}
