﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;
using System.Windows.Forms;

namespace MyOutlookTestWork
{
    public partial class ThisAddIn
    {
        internal Microsoft.Office.Tools.Ribbon.RibbonTab tab1;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup group1;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton button1;

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {

            // Get the Application object
            Outlook.Application application = this.Application;

            // Get the Inspectors objects
            Outlook.Inspectors inspectors = application.Inspectors;

            // Get the Explorers objects
            Outlook.Explorers explorers = application.Explorers;

            // Subscribe to the ItemSend event, that it's triggered when an email is sent
            application.ItemSend +=
                new Outlook.ApplicationEvents_11_ItemSendEventHandler(
                    ItemSend_BeforeSend);

        }

        void ItemSend_BeforeSend(object item, ref bool cancel)
        {
            Outlook.MailItem mailItem = (Outlook.MailItem)item;
            if (mailItem != null)
            {
                mailItem.Body += "С уважением, Григорий";
            }
            cancel = false;
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
            // Примечание. Outlook больше не выдает это событие. Если имеется код, который 
            //    должно выполняться при завершении работы Outlook, см. статью на странице https://go.microsoft.com/fwlink/?LinkId=506785
        }

        #region Код, автоматически созданный VSTO

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
}
